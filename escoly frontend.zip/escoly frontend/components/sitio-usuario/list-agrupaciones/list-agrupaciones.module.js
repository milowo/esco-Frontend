angular.module('listAgrupaciones', []);
