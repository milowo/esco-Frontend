angular.module('compraOrientacion', []);
