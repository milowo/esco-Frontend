angular.module('detalleOrientacion', []);
