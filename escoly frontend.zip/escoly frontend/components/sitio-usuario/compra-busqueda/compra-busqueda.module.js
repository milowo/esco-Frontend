angular.module('compraBusqueda', []);
