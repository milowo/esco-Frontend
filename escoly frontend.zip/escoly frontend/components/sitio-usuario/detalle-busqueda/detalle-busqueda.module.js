angular.module('detalleBusqueda', []);
