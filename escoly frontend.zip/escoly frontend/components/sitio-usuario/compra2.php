<?php

require_once('Pagadito.php');

//Sandbox
define("UID", "47641bfdf0bf904646e287b36f5bf69b");
define("WSK", "5107ab2022c48fc7f1309b63a801c907");

//Produccion
/*
define("UID", "60de88135d493795bf8b71241bf8c5bf");
define("WSK", "28050a027eb4b45ab02d8a6535bcc7af");
*/

if( (isset($_GET['monto'])) && (isset($_GET['cantidad'])) && (isset($_GET['tokencompra'])) ){

	$Descripcion = '';
	$tokencompra = $_GET['tokencompra'];
	$Cantidad = $_GET['cantidad'];
	if($tokencompra=='bba84e3e12ea7a891e02283fbcd46a88'){
		if($Cantidad=="1"){
			$Descripcion = $Cantidad . ' orientación Escoly';
		}else{
			$Descripcion = $Cantidad . ' orientaciones Escoly';
		}
	}else if($tokencompra=='71a45328063be6e4873e774db560a134'){
		if($Cantidad=="1"){
			$Descripcion = $Cantidad . ' búsqueda Escoly';
		}else{
			$Descripcion = $Cantidad . ' búsquedas Escoly';
		}
	}
	$Cantidad = $_GET['monto'];

	$Pagadito = new Pagadito(UID, WSK);
	$Pagadito->mode_sandbox_on();

	if ($Pagadito->connect()) {

		$Pagadito->add_detail(1, $Descripcion, $Cantidad, '');
		$ern = rand(1000, 2000);
		if (!$Pagadito->exec_trans($ern)) {
			echo $Pagadito->get_rs_code();
		}

	}else{
		echo $Pagadito->get_rs_code();
	}

}else{
	echo "Error en definición de parámetros de compra";
}



?>
