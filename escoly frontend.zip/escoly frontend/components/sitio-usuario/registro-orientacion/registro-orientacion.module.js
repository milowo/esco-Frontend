angular.module('registroOrientacion', []);
